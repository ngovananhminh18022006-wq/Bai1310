namespace AsyncProgressSinhVien;

public class Student
{
    public string StudentId { get; set; } = "";
    public string FullName { get; set; } = "";
    public int Age { get; set; }
    public string Gender { get; set; } = "";
}
